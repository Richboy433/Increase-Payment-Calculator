# Increase-Payment-Calculator

This Code Helps in calaculating the Amount of pay increase a particular staff deserves 
